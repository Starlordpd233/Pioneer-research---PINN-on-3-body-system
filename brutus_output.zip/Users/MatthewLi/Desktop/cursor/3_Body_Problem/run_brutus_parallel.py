#!/usr/bin/env python3
"""
Parallel Brutus Batch Runner - runs multiple simulations simultaneously

Run command:

python3 /Users/MatthewLi/Desktop/cursor/3_Body_Problem/run_brutus_parallel.py
"""

import subprocess
from pathlib import Path
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing

# Paths
BASE_DIR = Path("/Users/MatthewLi/Desktop/cursor")
BRUTUS_EXEC = BASE_DIR / "brutus_Newton-main" / "brutus"
IC_DIR = BASE_DIR / "3_Body_Problem" / "ic_raw_datasets"
OUTPUT_DIR = BASE_DIR / "3_Body_Problem" / "brutus_output"

# Brutus parameters
PARAMS = ["1e-11", "64", "0", "10", "0.01", "3"]

def run_simulation(input_file):
    """Run a single simulation - designed for parallel execution."""
    file_num = input_file.stem.split('_')[-1]
    output_path = OUTPUT_DIR / f"brutus_parallel_{file_num}.txt"
    
    cmd = [str(BRUTUS_EXEC)] + PARAMS + [str(input_file)]
    
    try:
        with open(output_path, 'w') as outfile:
            result = subprocess.run(cmd, 
                                  cwd=str(BRUTUS_EXEC.parent),
                                  stdout=outfile,
                                  stderr=subprocess.PIPE,
                                  text=True,
                                  timeout=300)  # 5-minute timeout per simulation
        return (input_file.name, True, "Success")
    except subprocess.TimeoutExpired:
        return (input_file.name, False, "Timeout")
    except Exception as e:
        return (input_file.name, False, str(e))

def main():
    OUTPUT_DIR.mkdir(exist_ok=True)

    input_files = sorted(
    [f for f in IC_DIR.iterdir() if f.suffix == '.txt'],
    key=lambda f: int(f.stem.split('_')[-1])
)[:50]
    
    # Determine number of parallel processes (leave 1 CPU free)
    num_cpus = max(1, multiprocessing.cpu_count() - 1)

    
    print(f"Starting parallel batch simulation of {len(input_files)} files")
    print(f"Using {num_cpus} parallel processes")
    print("-" * 60)
    
    start_time = time.time()
    completed = 0
    successful = 0
    
    with ProcessPoolExecutor(max_workers=num_cpus) as executor:
        # Submit all tasks
        futures = {executor.submit(run_simulation, f): f for f in input_files}
        
        # Process completed tasks as they finish
        for future in as_completed(futures):
            completed += 1
            filename, success, message = future.result()
            
            if success:
                successful += 1
                status = "✓"
            else:
                status = "✗"
            
            elapsed = time.time() - start_time
            rate = completed / elapsed
            eta = (len(input_files) - completed) / rate if rate > 0 else 0
            
            print(f"[{completed}/{len(input_files)}] {status} {filename} - {message}")
            print(f"    Progress: {successful}/{completed} successful, "
                  f"Rate: {rate:.1f} files/sec, ETA: {eta:.0f}s")
    
    total_time = time.time() - start_time
    print("\n" + "="*60)
    print(f"Completed {len(input_files)} simulations in {total_time:.1f} seconds")
    print(f"Successful: {successful}/{len(input_files)}")
    print(f"Average time per file: {total_time/len(input_files):.1f} seconds")
    print(f"Speedup factor: {len(input_files)*total_time/len(input_files)/total_time:.1f}x")
    print(f"\nOutput files saved in: {OUTPUT_DIR}")

if __name__ == "__main__":
    main()
