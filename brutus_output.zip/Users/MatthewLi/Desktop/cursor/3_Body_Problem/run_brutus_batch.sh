#!/bin/bash
# Brutus batch runner shell script

# Set paths
BRUTUS_DIR="/Users/MatthewLi/Desktop/cursor/brutus_Newton-main"
IC_DIR="/Users/MatthewLi/Desktop/cursor/3_Body_Problem/ic_raw_datasets"
OUTPUT_DIR="/Users/MatthewLi/Desktop/cursor/3_Body_Problem/brutus_output"

# Create output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"

# Counter for processed files
count=0
total=$(ls -1 "$IC_DIR"/*.txt | wc -l)

echo "Starting batch simulation of $total files..."
echo "========================================"

# Loop through all .txt files in the input directory
for input_file in "$IC_DIR"/ic_*.txt; do
    # Extract the number from filename
    filename=$(basename "$input_file")
    number="${filename#ic_}"
    number="${number%.txt}"
    
    # Create output filename
    output_file="$OUTPUT_DIR/brutus_${number}.txt"
    
    # Increment counter
    ((count++))
    
    # Print progress
    echo "[$count/$total] Processing $filename..."
    
    # Run Brutus simulation
    cd "$BRUTUS_DIR"
    ./brutus 1e-11 64 0 10 0.01 3 "$input_file" > "$output_file" 2>&1
    
    # Check if successful
    if [ $? -eq 0 ]; then
        echo "  ✓ Success - output saved to $(basename "$output_file")"
    else
        echo "  ✗ Failed"
    fi
done

echo "========================================"
echo "Batch simulation complete!"
echo "Output files saved in: $OUTPUT_DIR"
