'''
to navigate to the brutus folder to generate data, run the following command in terminal 
(cursor's integrated terminal or Mac's terminal):
cd ~/Desktop/cursor/brutus_Newton-main


Command for running simulation:

./brutus 1e-11 84   0   10   0.01    3   my_IC.txt  > output.txt
         │    │    │    │     │     │       └─────── input snapshot
         │    │    │    │     │     └────────────── Number of bodies
         │    │    │    │     └──────────────────── Bulirsch-Stoer time-step (dt)
         │    │    │    └────────────────────────── end time
         │    │    └─────────────────────────────── start time
         │    └──────────────────────────────────── working precision (digits)
         └──────────────────────────────────────── tolerance ε

type the absolute path for my_IC.txt and traj.out in the terminal (copy them from cursor's tab)

input ic.txt has the following format:

mass1 x1 y1 z1 vx1 vy1 vz1
mass2 x2 y2 z2 vx2 vy2 vz2
mass3 x3 y3 z3 vx3 vy3 vz3

'''

'''
With this current algorithm, how can we continue generating new files starting at 'ic_0100.txt' and so on without cahnging the previous ones? 
What if we need more simulations?
What are the various parameters that we can change to produce different batches of datasets which we can later use for curriculum learning?
How can we, most critically and importantly, adjust the BRUTUS parameters and configure it after testing to produce datasets with utmost accuracy?
What is the best way to categorize the datasets into different batches for gradual learning? 

I'm leaning towards the following approach, which catogorizes complexity based on potential energy:

1. Start by generating and training on rajectories that are shorter in duration (e.g., integrated for only about 5 dimensionless time units instead of the full 10).

2. For each valid initial condition (after collision avoidance), calculate a relevant physical invariant, such as the initial total potential energy 
E0​=∑j​21​mj​∣vj​∣2−G∑j<k​∣rj​−rk​∣mj​mk​​ (since initial velocities are zero, this simplifies to just the potential energy).

4. Define several "bins" or "stages" based on the values of this invariant (e.g., low energy, medium energy, high energy).

5. Run BRUTUS simulations for ICs falling into these different bins, creating separate sub-datasets for each stage.

6. Begin training the PINN only on the "easiest" stage (e.g., the lowest energy bin, which might correspond to more stable, less chaotic trajectories).

7. Once the PINN achieves satisfactory performance on this initial stage, introduce data from the next, more complex stage. 
The model can be fine-tuned on this new data, or trained on a combined dataset of current and previous stages.

If we adopt this, we'd have to create sub folders for each 'batch' based on their complexity with the folder 
'/Users/MatthewLi/Desktop/cursor/3_Body_Problem/ic_datasets' as the parent folder.

Each subfolder would be a batch 

Below is a sample structure of the folder:
ic_datasets/
├── curriculum_stage_1/  (e.g., low_energy_stable/)
│   ├── sim_00001.txt
│   ├── sim_00002.txt
│   └──...
├── curriculum_stage_2/  (e.g., medium_energy_chaotic/)
│   └──sim_00023.txt
├── non_converged_sims/
│   ├── failed_sim_A.txt
│   └──...
└── metadata_summary.csv (optional overall summary)

After fixing this, we'd have to figure out a way to save the BRUTUS output in an organized manner as well.


'''

import numpy as np
from scipy.stats import qmc
from typing import Tuple, Optional, Union
import warnings
import os

class ThreeBodySampler:
    """
    Hybrid quasi-random sampler for three-body initial conditions.
    Maintains Sobol sequence state for reproducible continuation.
    """
    
    def __init__(self, epsilon: float = 1e-6, scale_range: Tuple[float, float] = (1.0, 1.0),
                 rotate: bool = False, dtype: np.dtype = np.float64, seed: Optional[int] = None):
        """
        Initialize the sampler.
        
        Parameters:
        -----------
        epsilon : float
            Minimum allowed distance between particles
        scale_range : tuple of (float, float)
            Range for optional global scaling (min, max)
        rotate : bool
            Whether to apply random rotation (not implemented yet)
        dtype : numpy dtype
            Data type for output arrays
        seed : int, optional
            Random seed for Sobol scrambling
        """
        self.epsilon = epsilon
        self.scale_range = scale_range
        self.rotate = rotate
        self.dtype = dtype
        
        # Determine Sobol dimension based on features
        self.use_scaling = (scale_range[0] != scale_range[1])
        self.sobol_dim = 4 if self.use_scaling else 3
        if self.rotate:
            self.sobol_dim += 1
            
        # Initialize Sobol generator
        self.sobol = qmc.Sobol(d=self.sobol_dim, scramble=True, seed=seed)
        self.sobol_index = 0
        self.first_batch = True  # Track if this is the first batch
        
    def _process_sobol_batch(self, sobol_batch: np.ndarray, p1: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Process a batch of Sobol points into particle positions."""
        batch_size = len(sobol_batch)
        
        # Vectorized hemisphere mapping
        u1, u2, u3 = sobol_batch[:, 0], sobol_batch[:, 1], sobol_batch[:, 2]
        
        # Spherical coordinates (vectorized)
        cos_theta = 1 - 2 * u1
        sin_theta = np.sqrt(1 - cos_theta**2)
        phi = 2 * np.pi * u2
        
        # Enforce x ≤ 0 constraint
        needs_mirror = np.cos(phi) > 0
        phi[needs_mirror] = (phi[needs_mirror] + np.pi) % (2 * np.pi)
        
        # Direction vectors
        d = np.stack([
            sin_theta * np.cos(phi),
            sin_theta * np.sin(phi),
            cos_theta
        ], axis=-1)
        
        # Radial distances
        r = u3**(1/3)
        
        # Positions of particle 2
        p2_batch = r[:, np.newaxis] * d
        
        # Apply scaling if enabled
        if self.use_scaling:
            u4 = sobol_batch[:, 3]
            scale = self.scale_range[0] + (self.scale_range[1] - self.scale_range[0]) * u4
            p1_scaled = p1[np.newaxis, :] * scale[:, np.newaxis]
            p2_batch = p2_batch * scale[:, np.newaxis]
        else:
            p1_scaled = np.tile(p1, (batch_size, 1))
        
        # Positions of particle 3 (center of mass constraint)
        p3_batch = -(p1_scaled + p2_batch)
        
        return p1_scaled, p2_batch, p3_batch, sobol_batch
        
    def generate_batch(self, n_samples: int, max_rejection_factor: int = 100) -> Tuple[np.ndarray, np.ndarray, int]:
        """
        Generate a batch of initial conditions using Sobol sampling.
        
        Parameters:
        -----------
        n_samples : int
            Number of valid configurations requested
        max_rejection_factor : int
            Maximum ratio of attempts to requested samples before raising error
            
        Returns:
        --------
        positions : ndarray of shape (n_valid, 3, 3)
            Particle positions
        velocities : ndarray of shape (n_valid, 3, 3)
            Particle velocities (all zero)
        final_sobol_index : int
            Last Sobol index used (for continuation)
        """
        # Fix particle 1
        p1 = np.array([1.0, 0.0, 0.0], dtype=self.dtype)
        
        valid_positions = []
        total_attempts = 0
        
        # For the first batch, we can use random_base2 for optimal properties
        if self.first_batch and n_samples >= 16:  # Worth using base2 for larger batches
            # Estimate how many samples we need (accounting for ~20% rejection)
            m = int(np.ceil(np.log2(n_samples * 1.5)))
            m = min(m, 20)  # Cap at 2^20 = ~1M samples to avoid memory issues
            
            try:
                sobol_batch = self.sobol.random_base2(m)
                self.first_batch = False
                
                # Process the batch
                p1_scaled, p2_batch, p3_batch, _ = self._process_sobol_batch(sobol_batch, p1)
                
                # Vectorized collision checking
                d12 = np.linalg.norm(p1_scaled - p2_batch, axis=1)
                d13 = np.linalg.norm(p1_scaled - p3_batch, axis=1)
                d23 = np.linalg.norm(p2_batch - p3_batch, axis=1)
                
                # Valid configurations
                valid_mask = (d12 > self.epsilon) & (d13 > self.epsilon) & (d23 > self.epsilon)
                valid_indices = np.where(valid_mask)[0]
                
                # Collect valid configurations
                for idx in valid_indices[:n_samples]:  # Take only what we need
                    positions = np.stack([p1_scaled[idx], p2_batch[idx], p3_batch[idx]])
                    valid_positions.append(positions)
                
                self.sobol_index += len(sobol_batch)
                total_attempts += len(sobol_batch)
                
            except Exception as e:
                # Fall back to regular random() if base2 fails
                warnings.warn(f"random_base2 failed: {e}. Falling back to random().")
                self.first_batch = False
        
        # Use regular random() for continuation or small batches
        while len(valid_positions) < n_samples:
            # Determine batch size
            needed = n_samples - len(valid_positions)
            batch_size = min(max(needed * 2, 100), 10000)  # Adaptive batch size
            
            # Check if we're exceeding rejection limit
            if total_attempts + batch_size > n_samples * max_rejection_factor:
                raise RuntimeError(f"Epsilon {self.epsilon} too large: exceeded {max_rejection_factor}x "
                                 f"rejection limit. Generated only {len(valid_positions)}/{n_samples} samples.")
            
            # Generate batch of Sobol points using regular random()
            sobol_batch = self.sobol.random(batch_size)
            total_attempts += batch_size
            
            # Process the batch
            p1_scaled, p2_batch, p3_batch, _ = self._process_sobol_batch(sobol_batch, p1)
            
            # Vectorized collision checking
            d12 = np.linalg.norm(p1_scaled - p2_batch, axis=1)
            d13 = np.linalg.norm(p1_scaled - p3_batch, axis=1)
            d23 = np.linalg.norm(p2_batch - p3_batch, axis=1)
            
            # Valid configurations
            valid_mask = (d12 > self.epsilon) & (d13 > self.epsilon) & (d23 > self.epsilon)
            valid_indices = np.where(valid_mask)[0]
            
            # Collect valid configurations
            for idx in valid_indices:
                if len(valid_positions) < n_samples:
                    positions = np.stack([p1_scaled[idx], p2_batch[idx], p3_batch[idx]])
                    valid_positions.append(positions)
            
            self.sobol_index += batch_size
        
        # Convert to arrays
        positions_array = np.array(valid_positions[:n_samples], dtype=self.dtype)
        velocities_array = np.zeros_like(positions_array)
        
        return positions_array, velocities_array, self.sobol_index
    
    def save_brutus_format_single(self, position: np.ndarray, filename: str, mass: float = 1.0):
        """
        Save a single initial condition in BRUTUS format.
        
        Parameters:
        -----------
        position : ndarray of shape (3, 3)
            Particle positions for one configuration
        filename : str
            Output filename
        mass : float
            Mass of each particle (equal-mass system)
        """
        with open(filename, 'w') as f:
            # Write 3 lines, one per particle
            for particle_idx in range(3):
                x, y, z = position[particle_idx]
                # Format: mass x y z vx vy vz (all velocities are 0)
                f.write(f'{mass} {x} {y} {z} 0 0 0\n')
    
    def reset(self, seed: Optional[int] = None):
        """Reset the Sobol sequence."""
        self.sobol = qmc.Sobol(d=self.sobol_dim, scramble=True, seed=seed)
        self.sobol_index = 0
        self.first_batch = True


def generate_three_body_initial_conditions(
    n_samples: int,
    epsilon: float = 1e-6,
    scale_range: Tuple[float, float] = (1.0, 1.0),
    rotate: bool = False,
    dtype: np.dtype = np.float64,
    seed: Optional[int] = None,
    save_directory: Optional[str] = None,
    mass: float = 1.0
) -> Tuple[np.ndarray, np.ndarray, int]:
    """
    Functional interface for generating three-body initial conditions.
    
    Parameters:
    -----------
    n_samples : int
        Number of initial conditions to generate
    save_directory : str, optional
        If provided, saves each configuration to a separate file
    mass : float
        Mass of each particle
    
    Returns positions, velocities, and final Sobol index.
    """
    sampler = ThreeBodySampler(epsilon, scale_range, rotate, dtype, seed)
    
    positions, velocities, final_index = sampler.generate_batch(n_samples)
    
    # Save individual files if directory is provided
    if save_directory:
        os.makedirs(save_directory, exist_ok=True)
        for i in range(n_samples):
            filename = os.path.join(save_directory, f'ic_{i:04d}.txt')
            sampler.save_brutus_format_single(positions[i], filename, mass)
    
    return positions, velocities, final_index


# Unit tests
def test_three_body_sampling():
    """Comprehensive tests for the sampling method."""
    
    # Test 1: Basic generation
    sampler = ThreeBodySampler(epsilon=0.01, seed=42)
    pos, vel, idx = sampler.generate_batch(10)
    
    # Check shapes
    assert pos.shape == (10, 3, 3), f"Wrong position shape: {pos.shape}"
    assert vel.shape == (10, 3, 3), f"Wrong velocity shape: {vel.shape}"
    assert np.allclose(vel, 0), "Velocities should be zero"
    
    # Test 2: Center of mass constraint
    com = pos.mean(axis=1)  # Center of mass for each configuration
    assert np.allclose(com, 0, atol=1e-12), f"Center of mass not at origin: max deviation = {np.abs(com).max()}"
    
    # Test 3: Hemisphere constraint for p2
    p2_x = pos[:, 1, 0]  # x-coordinates of particle 2
    assert np.all(p2_x <= 1e-12), f"Particle 2 not in x≤0 hemisphere: max x = {p2_x.max()}"
    
    # Test 4: Collision constraint
    for i in range(len(pos)):
        d12 = np.linalg.norm(pos[i, 0] - pos[i, 1])
        d13 = np.linalg.norm(pos[i, 0] - pos[i, 2])
        d23 = np.linalg.norm(pos[i, 1] - pos[i, 2])
        assert d12 > 0.01, f"Config {i}: d12 = {d12} violates epsilon"
        assert d13 > 0.01, f"Config {i}: d13 = {d13} violates epsilon"
        assert d23 > 0.01, f"Config {i}: d23 = {d23} violates epsilon"
    
    # Test 5: Particle 1 position (accounting for possible scaling)
    if sampler.scale_range == (1.0, 1.0):
        p1_expected = np.array([1.0, 0.0, 0.0])
        assert np.allclose(pos[:, 0, :], p1_expected), "Particle 1 not at (1,0,0)"
    
    # Test 6: Reproducibility
    sampler2 = ThreeBodySampler(epsilon=0.01, seed=42)
    pos2, _, _ = sampler2.generate_batch(10)
    assert np.allclose(pos, pos2), "Same seed should give same results"
    
    # Test 7: Continuation
    pos_cont, _, idx2 = sampler.generate_batch(5)
    assert idx2 > idx, "Sobol index should advance"
    assert pos_cont.shape == (5, 3, 3), "Continuation should work"
    
    # Test 8: Power of 2 generation
    sampler_p2 = ThreeBodySampler(epsilon=0.01, seed=123)
    pos_p2, _, _ = sampler_p2.generate_batch(64)  # Exactly 2^6
    assert pos_p2.shape == (64, 3, 3), "Power of 2 generation should work"
    
    print("All tests passed! ✓")


if __name__ == "__main__":
    # Run tests to ensure everything works
    test_three_body_sampling()
    
    # Generate 100 initial condition files
    n_simulations = 100
    epsilon = 0.01    # Minimum separation between particles
    mass = 1.0        # Mass of each particle
    output_dir = "/Users/MatthewLi/Desktop/cursor/3_Body_Problem/ic_raw_datasets"
    
    print(f"\nGenerating {n_simulations} three-body initial condition files...")
    
    positions, velocities, final_idx = generate_three_body_initial_conditions(
        n_samples=n_simulations,
        epsilon=epsilon,
        seed=42,  # For reproducibility
        save_directory=output_dir,
        mass=mass
    )
    
    print(f"✓ Generated {len(positions)} configurations")
    print(f"✓ Saved to {output_dir}/ic_0000.txt through ic_{n_simulations-1:04d}.txt")
    print(f"✓ Final Sobol index: {final_idx}")
    
    # Print some statistics about the generated data
    print("\nConfiguration statistics:")
    all_distances = []
    for i in range(len(positions)):
        d12 = np.linalg.norm(positions[i, 0] - positions[i, 1])
        d13 = np.linalg.norm(positions[i, 0] - positions[i, 2])
        d23 = np.linalg.norm(positions[i, 1] - positions[i, 2])
        all_distances.extend([d12, d13, d23])
    
    all_distances = np.array(all_distances)
    print(f"  Min particle separation: {all_distances.min():.4f}")
    print(f"  Mean particle separation: {all_distances.mean():.4f}")
    print(f"  Max particle separation: {all_distances.max():.4f}")
    
    # Show example of first file content
    first_file = os.path.join(output_dir, "ic_0000.txt")
    if os.path.exists(first_file):
        print(f"\nExample content of {first_file}:")
        with open(first_file, 'r') as f:
            print(f.read())