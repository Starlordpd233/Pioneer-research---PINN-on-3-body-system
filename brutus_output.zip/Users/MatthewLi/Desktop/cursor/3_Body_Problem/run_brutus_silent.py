#!/usr/bin/env python3
"""
Silent Brutus Batch Runner - runs without user interaction

Run command:

python3 /Users/MatthewLi/Desktop/cursor/3_Body_Problem/run_brutus_silent.py
"""

import os
import subprocess
from pathlib import Path
import time

# Paths
BASE_DIR = Path("/Users/MatthewLi/Desktop/cursor")
BRUTUS_EXEC = BASE_DIR / "brutus_Newton-main" / "brutus"
IC_DIR = BASE_DIR / "3_Body_Problem" / "ic_raw_datasets"
OUTPUT_DIR = BASE_DIR / "3_Body_Problem" / "brutus_output"

# Brutus parameters
PARAMS = ["1e-11", "64", "0", "10", "0.01", "3"]

def main():
    OUTPUT_DIR.mkdir(exist_ok=True)
    input_files = sorted([f for f in IC_DIR.iterdir() if f.suffix == '.txt'])
    
    print(f"Starting batch simulation of {len(input_files)} files...")
    start_time = time.time()
    
    for i, input_file in enumerate(input_files):
        file_num = input_file.stem.split('_')[-1]
        output_path = OUTPUT_DIR / f"brutus_{file_num}.txt"
        
        cmd = [str(BRUTUS_EXEC)] + PARAMS + [str(input_file)]
        
        with open(output_path, 'w') as outfile:
            subprocess.run(cmd, cwd=str(BRUTUS_EXEC.parent), 
                         stdout=outfile, stderr=subprocess.DEVNULL)
        
        print(f"[{i+1}/{len(input_files)}] Processed {input_file.name}")
    
    print(f"\nCompleted in {time.time() - start_time:.1f} seconds")
    print(f"Output files saved in: {OUTPUT_DIR}")

if __name__ == "__main__":
    main()
