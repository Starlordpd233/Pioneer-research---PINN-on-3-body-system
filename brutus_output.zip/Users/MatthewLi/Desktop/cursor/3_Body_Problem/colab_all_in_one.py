# Complete Google Colab Script for Brutus Simulations
# Copy this entire script into a single Colab cell

import subprocess
import time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing

# Step 1: Upload files
print("=" * 60)
print("STEP 1: Upload your files")
print("=" * 60)
from google.colab import files

print("Please upload brutus_Newton-main.zip")
uploaded = files.upload()

print("\nPlease upload ic_datasets.zip")
uploaded = files.upload()

# Step 2: Extract files
print("\n" + "=" * 60)
print("STEP 2: Extracting files")
print("=" * 60)
!unzip -q brutus_Newton-main.zip
!unzip -q ic_datasets.zip -d ic_raw_datasets_temp
!mv ic_raw_datasets_temp/ic_raw_datasets .
!rmdir ic_raw_datasets_temp

# Step 3: Compile Brutus
print("\n" + "=" * 60)
print("STEP 3: Compiling Brutus")
print("=" * 60)
!apt-get update -qq
!apt-get install -y g++ make -qq

import os
os.chdir('brutus_Newton-main')
!make clean > /dev/null 2>&1
!make
os.chdir('..')

# Step 4: Create output directory
!mkdir -p brutus_output

# Step 5: Run simulations
print("\n" + "=" * 60)
print("STEP 4: Running Simulations")
print("=" * 60)

def run_simulation(input_file):
    """Run a single simulation."""
    file_num = input_file.stem.split('_')[-1]
    output_path = Path("brutus_output") / f"brutus_{file_num}.txt"
    
    cmd = ["./brutus_Newton-main/brutus", "1e-11", "64", "0", "10", "0.01", "3", str(input_file)]
    
    try:
        with open(output_path, 'w') as outfile:
            subprocess.run(cmd, stdout=outfile, stderr=subprocess.PIPE, timeout=300)
        return True
    except:
        return False

# Get all input files
input_files = sorted(Path("ic_raw_datasets").glob("*.txt"))
print(f"Found {len(input_files)} input files")

# Run in parallel
start_time = time.time()
successful = 0

with ProcessPoolExecutor(max_workers=multiprocessing.cpu_count()) as executor:
    futures = [executor.submit(run_simulation, f) for f in input_files]
    
    for i, future in enumerate(as_completed(futures)):
        if future.result():
            successful += 1
        print(f"Progress: {i+1}/{len(input_files)} files processed", end='\r')

total_time = time.time() - start_time
print(f"\n\nCompleted in {total_time:.1f} seconds")
print(f"Successful: {successful}/{len(input_files)}")

# Step 6: Download results
print("\n" + "=" * 60)
print("STEP 5: Preparing download")
print("=" * 60)
!zip -r brutus_results.zip brutus_output/
files.download('brutus_results.zip')
print("Download started!")
