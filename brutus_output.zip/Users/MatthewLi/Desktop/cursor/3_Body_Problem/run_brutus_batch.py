#!/usr/bin/env python3
"""
Automated Brutus Simulation Runner
This script loops through all initial condition files in ic_raw_datasets
and runs the Brutus simulation on each one, saving outputs to brutus_output.

Run command:

python3 /Users/MatthewLi/Desktop/cursor/3_Body_Problem/run_brutus_batch.py
"""

import os
import subprocess
import time
from pathlib import Path

# Define paths
BASE_DIR = Path("/Users/MatthewLi/Desktop/cursor")
BRUTUS_DIR = BASE_DIR / "brutus_Newton-main"
PROBLEM_DIR = BASE_DIR / "3_Body_Problem"
IC_DIR = PROBLEM_DIR / "ic_raw_datasets"
OUTPUT_DIR = PROBLEM_DIR / "brutus_output"

# Brutus executable path
BRUTUS_EXEC = BRUTUS_DIR / "brutus"

# Brutus parameters
PARAMS = ["1e-11", "64", "0", "10", "0.01", "3"]

def run_single_simulation(input_file, output_file):
    """Run Brutus simulation for a single input file."""
    # Build the command
    cmd = [str(BRUTUS_EXEC)] + PARAMS + [str(input_file)]
    
    try:
        # Run the command and capture output
        print(f"Running: {' '.join(cmd)}")
        with open(output_file, 'w') as outfile:
            result = subprocess.run(cmd, 
                                    cwd=str(BRUTUS_DIR),  # Run from brutus directory
                                    stdout=outfile,
                                    stderr=subprocess.PIPE,
                                    text=True,
                                    check=True)
        
        if result.stderr:
            print(f"  Warning: {result.stderr}")
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"  Error running simulation: {e}")
        if e.stderr:
            print(f"  Error details: {e.stderr}")
        return False
    except Exception as e:
        print(f"  Unexpected error: {e}")
        return False

def main():
    """Main function to run all simulations."""
    print("="*60)
    print("BRUTUS BATCH SIMULATION RUNNER")
    print("="*60)
    
    # Create output directory if it doesn't exist
    OUTPUT_DIR.mkdir(exist_ok=True)
    
    # Get all input files sorted by name
    input_files = sorted([f for f in IC_DIR.iterdir() if f.suffix == '.txt'])
    total_files = len(input_files)
    
    print(f"\nFound {total_files} input files in {IC_DIR}")
    print(f"Output will be saved to {OUTPUT_DIR}")
    print(f"Using Brutus executable at {BRUTUS_EXEC}")
    print(f"\nBrutus parameters: {' '.join(PARAMS)}")
    
    # Confirm before starting
    response = input("\nProceed with batch simulation? (y/n): ")
    if response.lower() != 'y':
        print("Batch simulation cancelled.")
        return
    
    print("\nStarting batch simulation...")
    print("-"*60)
    
    successful = 0
    failed = 0
    start_time = time.time()
    
    for i, input_file in enumerate(input_files):
        # Extract the number from filename (e.g., ic_0042.txt -> 0042)
        file_num = input_file.stem.split('_')[-1]
        output_filename = f"brutus_{file_num}.txt"
        output_path = OUTPUT_DIR / output_filename
        
        print(f"\n[{i+1}/{total_files}] Processing {input_file.name} -> {output_filename}")
        
        # Run simulation
        if run_single_simulation(input_file, output_path):
            successful += 1
            print(f"  ✓ Success! Output saved to {output_path}")
        else:
            failed += 1
            print(f"  ✗ Failed!")
        
        # Show progress
        elapsed = time.time() - start_time
        avg_time = elapsed / (i + 1)
        remaining = avg_time * (total_files - i - 1)
        
        print(f"  Progress: {successful} successful, {failed} failed")
        print(f"  Time elapsed: {elapsed:.1f}s, estimated remaining: {remaining:.1f}s")
    
    # Final summary
    total_time = time.time() - start_time
    print("\n" + "="*60)
    print("BATCH SIMULATION COMPLETE")
    print("="*60)
    print(f"Total files processed: {total_files}")
    print(f"Successful: {successful}")
    print(f"Failed: {failed}")
    print(f"Total time: {total_time:.1f} seconds ({total_time/60:.1f} minutes)")
    print(f"Average time per simulation: {total_time/total_files:.1f} seconds")
    print(f"\nOutput files saved in: {OUTPUT_DIR}")

if __name__ == "__main__":
    main()
